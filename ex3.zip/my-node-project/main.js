const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());

const list_data = []
app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.get('/show', (req, res) => {
  res.send(list_data);
});

app.post('/insert', (req, res) => {
  const body = req.body
  const keyValue  = list_data.length
  list_data.push({...body, key: keyValue})
  console.log("list_data => ", list_data)
  res.send("insert success");
});

app.post('/update', (req, res) => {
  const body = req.body
  const indexValue = list_data.findIndex(f => f.key == body.key);
  list_data[indexValue].name = body.name
  list_data[indexValue].detail = body.detail
  list_data[indexValue].date = body.date
  
  res.send("update success");
});

app.post('/delete', (req, res) => {
  const body = req.body
  list_data.splice(body.key, 1);
  res.send("delete success");
});


app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});



